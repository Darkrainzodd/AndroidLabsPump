package com.morita.vacation;

/**
 * Created by student on 6/22/2015.
 */
public class GalleryItem {
    private String mCaption;
    private String mId;
    private String mUrl;
    private String mOwnder;

    public String toString() {
        return mCaption;

    }

    public String getId() {
        return mId;
    }

    public String getUrl() {
        return mUrl;
    }

    public void setUrl(String mUrl) {
        this.mUrl = mUrl;
    }

    public void setId(String mId) {

        this.mId = mId;
    }

    public String getmOwnder() {
        return mOwnder;
    }

    public void setmOwnder(String mOwnder) {
        this.mOwnder = mOwnder;
    }

    public String getPhotoPageUrl() {
        return "https://www.flickr.com/photos/" + mOwnder + "/" + mId;
    }

    public String getCaption() {
        return mCaption;

    }

    public void setCaption(String mCaption) {
        this.mCaption = mCaption;
    }
}
