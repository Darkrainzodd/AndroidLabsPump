package com.morita.vacation;

/**
 * Created by Student on 8/10/2015.
 */
public class MainActivity {
}
