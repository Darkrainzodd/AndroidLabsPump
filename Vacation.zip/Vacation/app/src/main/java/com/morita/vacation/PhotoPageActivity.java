package com.morita.vacation;

import android.support.v4.app.Fragment;

/**
 * Created by Student on 8/10/2015.
 */
public class PhotoPageActivity extends SingleFragmentActivity {

    @Override
    public Fragment createFragment() {
        return new PhotoPageFragment();
    }
}
